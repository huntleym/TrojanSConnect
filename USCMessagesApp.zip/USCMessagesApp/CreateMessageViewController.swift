    //
    //  ViewController.swift
    //  FinalProject
    //
    //  Created by Matthew Myrtue on 3/28/18.
    //  Copyright © 2018 CSCI 201. All rights reserved.
    //

import UIKit
import AVFoundation

class CreateMessageViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate,
AVAudioPlayerDelegate, AVAudioRecorderDelegate, UITextFieldDelegate {
    
    var currentLongitude = Double()
    var currentLatitude = Double()
    
    @IBAction func dismissPopup(_ sender: UIButton) { //activated by the close window button
        dismiss(animated: true, completion: nil)
        
    }
    
    //stepper and associated variable
    @IBOutlet weak var valueLabel: UILabel!
    @IBOutlet weak var stepper: UIStepper!
    
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        valueLabel.text = Int(sender.value).description
    }
        
    //variable to store URLs for message class
    var soundFileURL : String?
    var soundFileURLForDatabase: String?
    
    //variables that store the 3 methods of user input
    var txt : String?
    var picture : UIImage?
    var audio : AVAudioFile?
    
    
    //elements for recording audio
    
    
    var audioPlayer: AVAudioPlayer?
    var audioRecorder: AVAudioRecorder?

    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
        
        
    @IBAction func recordAudio(_ sender: Any) {
            if audioRecorder?.isRecording == false {
                playButton.isEnabled = false
                stopButton.isEnabled = true
                audioRecorder?.record()
            }
    }

    
    @IBAction func stopAudio(_ sender: Any) {
        stopButton.isEnabled = false
        playButton.isEnabled = true
        recordButton.isEnabled = true
        
        
        if audioRecorder?.isRecording == true {
            audioRecorder?.stop()
        } else {
            audioPlayer?.stop()
        }
    }
    
    
    @IBAction func playAudio(_ sender: Any) {
        if audioRecorder?.isRecording == false {
            stopButton.isEnabled = true
            recordButton.isEnabled = false
            
            
            do {
                try audioPlayer = AVAudioPlayer(contentsOf:
                    (audioRecorder?.url)!)
                audioPlayer!.delegate = self
                audioPlayer!.prepareToPlay()
                audioPlayer!.play()
            } catch let error as NSError {
                print("audioPlayer error: \(error.localizedDescription)")
            }
        }
    }
        

    @IBOutlet weak var textMessage: UITextField!
    @IBOutlet weak var imagePicked: UIImageView!
    
        
    @IBAction func openCameraButton(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }


    @IBAction func openPhotoLibraryButton(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imagePicked.contentMode = .scaleAspectFit
            imagePicked.image = pickedImage
            //            savedPickedImage = pickedImage
        }
        self.dismiss(animated: true, completion: nil);
    }
    
    func saveImageToDocumentDirectory(_ chosenImage: UIImage) -> String {
        let directoryPath =  NSHomeDirectory().appending("/Documents/")
        if !FileManager.default.fileExists(atPath: directoryPath) {
            do {
                try FileManager.default.createDirectory(at: NSURL.fileURL(withPath: directoryPath), withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error)
            }
        }
        let filename = NSDate().description.appending(".jpg")
        let filepath = directoryPath.appending(filename)
        let url = NSURL.fileURL(withPath: filepath)
        print("IMAGE URL 1--")
        print(url)
        do {
            try UIImageJPEGRepresentation(chosenImage, 1.0)?.write(to: url, options: .atomic)
            return filename
            
            
        } catch {
            print(error)
            print("file cant not be save at path \(filepath), with error : \(error)");
            return filepath
        }
    }

    @IBAction func submitMessage(_ sender: Any) {
        let txt = textMessage.text
        
        
        //getting the image filepath
        let img = imagePicked.image
        let filename = saveImageToDocumentDirectory(img!)
        //testing the image loading
        
        
        let days = Int(stepper.value)
        let audio = soundFileURLForDatabase
        
        //starting the servlet call
        let myUrl = URL(string: "http://localhost:8080/servlets/CreateMessage");
        var request = URLRequest(url:myUrl!)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"// Compose a query string
        
        
        let parameters = [
            "messageID": -1,
            "text": txt,
            "audio": audio,
            "image": filename,
            "flagCount":0,
            "loc_x": -59.3,
            "loc_y": 53.98
            ] as [String : Any]
        
        do{
            let jsondata = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            request.httpBody = jsondata
        }catch {
            print(error)
        }
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            
            if error != nil
            {
                print("error=\(error)")
                return
            }
            
            
            // You can print out response object
            print("response = \(response)")
            
            
            //Let's convert response sent from a server side script to a NSDictionary object:
            //            do {
            //                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
            //
            //                if let parseJSON = json {
            //
            //                    // Now we can access value of First Name by its key
            //                    let firstNameValue = parseJSON["firstName"] as? String
            //                    print("firstNameValue: \(firstNameValue)")
            //                }
            //            } catch {
            //                print(error)
            //            }
        }
        task.resume()
        
        
    }
    
        
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        recordButton.isEnabled = true
        stopButton.isEnabled = false
    }
        
    
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        print("Audio Play Decode Error")
    }
    
        
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
    }
        
        
    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        print("Audio Record Encode Error")
    }
        
        
    //hide the keyboard when user selects outside
    
        
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
        
    //presses return key
        
        
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return (true)
    }
        
        
    func getDirectory() ->URL{
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = paths[0]
        return documentDirectory
    }
        
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(currentLongitude)
        print(currentLatitude)
        
        //set delegate of the text field
        self.textMessage.delegate = self
        
        //hide play and stop buttons if no audio recorded (default)
        self.playButton.isHidden = true
        self.stopButton.isHidden = true
        
            
        stepper.minimumValue = 1
        stepper.maximumValue = 30
        // Do any additional setup after loading the view, typically from a nib.
        playButton.isEnabled = false
        stopButton.isEnabled = false
            
        let soundFileURLForDatabase = getDirectory().appendingPathComponent("sound.m4a").absoluteString
        let soundFileURL = getDirectory().appendingPathComponent("sound.m4a")
        print(soundFileURL)
            
            
        let recordSettings =
            [AVEncoderAudioQualityKey: AVAudioQuality.min.rawValue,
            AVEncoderBitRateKey: 16,
                AVNumberOfChannelsKey: 2,
                AVSampleRateKey: 44100.0,
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC)] as [String : Any]
            
            
        let audioSession = AVAudioSession.sharedInstance()
            
            
        do {
            try audioSession.setCategory(
                AVAudioSessionCategoryPlayAndRecord)
            try! audioSession.overrideOutputAudioPort(.speaker)
        } catch let error as NSError {
            print("audioSession error: \(error.localizedDescription)")
        }
            
            
        do {
            try audioRecorder = AVAudioRecorder(url: soundFileURL,
                                                    settings: recordSettings as [String : AnyObject])
            audioRecorder?.prepareToRecord()
        } catch let error as NSError {
            print("audioSession error: \(error.localizedDescription)")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        
        
}
