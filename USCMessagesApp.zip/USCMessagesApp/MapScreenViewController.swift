//
//  MapScreenViewController.swift
//  USCMessagesApp
//
//  Created by Hongze Yu, Michelle Huntley on 3/30/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class MapScreenViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    

    @IBOutlet weak var createMessageButton: UIButton!
    @IBOutlet weak var viewMessageButton: UIButton!
    @IBOutlet weak var mainMenuButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    
    var currentlongitude = 0.0
    var currentlatitude = 0.0
    @IBAction func hideButtonsWhenCreateMessageButtonClicked(_ sender: Any) {
//        self.createMessageButton.isHidden = true
//        self.viewMessageButton.isHidden = true
//        self.mainMenuButton.isHidden = true
        //print (currentlongitude)---code for getting user's location
        //print (currentlatitude)
    }
    
    @IBAction func hideButtonsWhenViewMessageButtonClicked(_ sender: Any) {
//        self.createMessageButton.isHidden = true
//        self.viewMessageButton.isHidden = true
//        self.mainMenuButton.isHidden = true
    }
    
    
    //Map
    @IBOutlet weak var map: MKMapView!
    
    let manager = CLLocationManager()
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.001,0.001)
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, span)
        map.setRegion(region, animated: true)
        self.map.showsUserLocation = true
        currentlatitude = location.coordinate.latitude
        currentlongitude = location.coordinate.longitude
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //hide logout and create message button if the user is not logged in
        if (!LoginSession.shareInstance.isLogin) {
            //logout button -- redirects to main menu
            self.logoutButton.isHidden = true
            
            //create message button
            self.createMessageButton.isHidden = true
        }
        
        //hide main menu button if user is logged in 
        if (LoginSession.shareInstance.isLogin) {
            self.mainMenuButton.isHidden = true
        }
        
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        //get latitude and longitude values for all the messages within the user's radius from the server
        let arrlongitude = [34.025832, 34.025341, 34.026269]
        let arrlatitude = [-118.287401, -118.287254, -118.287003]
        
        var i = 0
        
        while (i<3){
            let longitude = arrlongitude[i]
            let latitude = arrlatitude[i]
            let annolocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(longitude, latitude)
            let annotation = MKPointAnnotation()
            annotation.coordinate = annolocation
            annotation.title = "View Me!"
            map.addAnnotation(annotation)
            i+=1
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "CreateMessageSegue") {
            var DestViewController : CreateMessageViewController = segue.destination as! CreateMessageViewController
            
            DestViewController.currentLongitude = self.currentlongitude
            DestViewController.currentLatitude = self.currentlatitude
        }
        if (segue.identifier == "ViewMessageSegue") {
            var DestViewController : ViewMessageViewController = segue.destination as! ViewMessageViewController
            
            DestViewController.currentLongitude = self.currentlongitude
            DestViewController.currentLatitude = self.currentlatitude
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
}
