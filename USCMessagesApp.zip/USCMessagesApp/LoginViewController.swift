//
//  LoginViewController.swift
//  USCMessagesApp
//
//  Created by Michelle Huntley on 3/29/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBAction func backButtonPressed(_ sender: UIButton) {
        self.performSegue(withIdentifier: "LoginBackButton", sender: self)
    
    }
    
    //global variable
    var errorMessage = ""
    var invalidData = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        userNameField.delegate = self
        passwordField.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func enterTapped(_ sender: Any) {
        let username = userNameField.text!
        let password = passwordField.text!
        

        if (username == "") {
            errorMessage = "Username cannot be empty"
            invalidData = true
        }
        else if (password == "") {
            errorMessage = "Password cannot be empty"
            invalidData = true
        }
        else {
            invalidData = false
        }
        
        //validate login data
        //var errorMessage = validateLogin(username: username, password: password)
        
        //test
        if (username == "michelle") {
            errorMessage = "Username does not exist"
            invalidData = true
        }
        
        //now redirect user to a certain page depending on if login data could be validated
        if (!invalidData) {
            //empty string returned, so no error
            DispatchQueue.main.async(execute: self.loginDone)
        }
        else {
            //error message
            DispatchQueue.main.async(execute: self.loginError)
        }
    }
    
    func loginDone() {
        //since login is successful, we alert the session object (LoginSession)
        LoginSession.shareInstance.isLogin = true
        
        //redirect user to map screen
        self.performSegue(withIdentifier: "goToMapScreen", sender: self)
    }
    
    func loginError() {
        //stay on page, display error message in popup window

        //perform the segue displayErrorMessage that opens up the error message popup window
        self.performSegue(withIdentifier: "displayErrorMessage", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "displayErrorMessage") {
            var DestViewController : ErrorMessagePopup = segue.destination as! ErrorMessagePopup
            DestViewController.LabelText = errorMessage
        }
    }
}

extension LoginViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}

