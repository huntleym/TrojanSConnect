//
//  Message.swift
//  FinalProject
//
//  Created by Matthew Myrtue on 3/28/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

class UserMessage{
    var textMessage: String
    var picture: Data?
    var audio: String
    var timeRemaining: Int
    
    
    init(textMessage:String, picture:Data?, audio: String, timeRemaining:Int) {
        self.textMessage = textMessage;
        self.picture = picture;
        self.audio = audio;
        self.timeRemaining = timeRemaining;
    }
}
