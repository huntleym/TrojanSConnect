//
//  ErrorMessagePopup.swift
//  USCMessagesApp
//
//  Created by Michelle Huntley on 4/13/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import Foundation
import UIKit

class ErrorMessagePopup : UIViewController {
    
    @IBOutlet weak var errorMessage: UILabel!
    
    var LabelText = String()
    
    override func viewDidLoad() {
        errorMessage.text = LabelText
    }
    
    @IBAction func dismissPopup(_ sender: Any) {
        dismiss(animated: true)
    }
}
