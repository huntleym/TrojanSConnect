//
//  SignupViewController.swift
//  USCMessagesApp
//
//  Created by Michelle Huntley on 3/30/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {
    
    var errorMessage = ""
    var invalidData = false
    
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var confirmPasswordField: UITextField!
    
    @IBAction func backButtonPressed(_ sender: UIButton) {
    
        self.performSegue(withIdentifier: "SignupBackButton", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameField.delegate = self
        passwordField.delegate = self
        
    }
    
    @IBAction func enterTapped(_ sender: UIButton) {
        let username = userNameField.text!
        let password = passwordField.text!
        let confirmPassword = confirmPasswordField.text!
        
        //if username field is empty
        if (username == "") {
            errorMessage = "Username cannot be empty"
            invalidData = true
        }
        //if password field is empty 
        else if (password == "") {
            errorMessage = "Password cannot be empty"
            invalidData = true
        }
        //if confirm password field is empty
        else if (confirmPassword == "") {
            errorMessage = "Please confirm password"
            invalidData = true
        }
        //if passwords do not match
        else if (password != confirmPassword) {
            print(password)
            print(confirmPassword)
            errorMessage = "Passwords do not match"
            invalidData = true
        }
        else {
            invalidData = false
        }
        
        //send data entered to server to validate it
        //var errorMessage = validateLogin(username: username, password: password)

        //if username is taken
        if (username == "michelle") {
            errorMessage = "Username taken"
        }
        
        //now redirect user to a certain page depending on if data could be validated
        if (!invalidData) {
            //empty string returned, so no error
            DispatchQueue.main.async(execute: self.signupDone)
        }
        else {
            //error message
            DispatchQueue.main.async(execute: self.signupError)
        }
    }
    
    func signupDone() {
        //indicate in the LoginSession that the user is logged in
        LoginSession.shareInstance.isLogin = true
        
        //redirect user to map screen
        self.performSegue(withIdentifier: "goToMapScreen", sender: self)
    }
    
    func signupError() {
        //stay on page, display error message in popup
        
        //perform segue displayErrorMessage
        self.performSegue(withIdentifier: "displayErrorMessage", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "displayErrorMessage") {
            var DestViewController : ErrorMessagePopup = segue.destination as! ErrorMessagePopup
            DestViewController.LabelText = errorMessage
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension SignupViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
