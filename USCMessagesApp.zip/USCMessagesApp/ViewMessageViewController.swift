//
//  ViewMessageViewController.swift
//  USCMessagesApp
//
//  Created by Michelle Huntley on 4/2/18.
//  Copyright © 2018 CSCI 201. All rights reserved.
//

import UIKit

class ViewMessageViewController: UIViewController {
    
    var currentLongitude = Double()
    var currentLatitude = Double()
    
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    
    
    @IBAction func dismissPopup(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.pauseButton.isHidden = true
        
        //print statements for testing
        print(currentLongitude)
        print(currentLatitude)
        
        let myUrl = URL(string: "http://localhost:8080/CSCI201GroupProject-Backend/ViewMessage");
        var request = URLRequest(url:myUrl!)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"// Compose a query string
        
        var longitudeString: String = String(format:"%.1f", currentLongitude)
        var latitudeString: String = String(format:"%.1f", currentLatitude)
        
        var locationString = "\(longitudeString),\(latitudeString)"
        
        request.httpBody = locationString.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
        }
        task.resume()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
